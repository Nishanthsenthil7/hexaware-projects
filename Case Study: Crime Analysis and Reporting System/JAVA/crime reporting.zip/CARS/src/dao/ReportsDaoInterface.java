package dao;

import entity.Incidents;
import entity.Reports;

public interface ReportsDaoInterface {
	 public void CreateReport(Incidents incident);
	  public boolean addReport(Reports object);
}
