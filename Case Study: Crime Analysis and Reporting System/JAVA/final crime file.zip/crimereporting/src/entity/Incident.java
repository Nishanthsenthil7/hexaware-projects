package entity;

import java.time.LocalDate;
import java.util.Date;

public class Incident {
    private int incidentId;
    private String incidentType;
    private Date incidentDate;
    private double latitude;
    private double longitude;
    private String description;
    private String status;
    private int agencyId;
    private int officerId;

    // Constructors
    public Incident() {}
    public Incident(int id, String type, Date date, double lat, double lon, String desc, String status, int agencyId, int officerId) {
        this.setIncidentId(id);
        this.setIncidentType(type);
        this.setIncidentDate(date);
        this.setLatitude(lat);
        this.setLongitude(lon);
        this.setDescription(desc);
        this.setStatus(status);
        this.setAgencyId(agencyId);
        this.setOfficerId(officerId);
    }
	public Incident(int i, String type, LocalDate date, double lat, double lon, String desc, String status2,
			int agencyId2, int officerId2) {
		// TODO Auto-generated constructor stub
	}
	public int getIncidentId() {
		return incidentId;
	}
	public void setIncidentId(int incidentId) {
		this.incidentId = incidentId;
	}
	public String getIncidentType() {
		return incidentType;
	}
	public void setIncidentType(String incidentType) {
		this.incidentType = incidentType;
	}
	public Date getIncidentDate() {
		return incidentDate;
	}
	public void setIncidentDate(Date incidentDate) {
		this.incidentDate = incidentDate;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getAgencyId() {
		return agencyId;
	}
	public void setAgencyId(int agencyId) {
		this.agencyId = agencyId;
	}
	public int getOfficerId() {
		return officerId;
	}
	public void setOfficerId(int officerId) {
		this.officerId = officerId;
	}

  
}
