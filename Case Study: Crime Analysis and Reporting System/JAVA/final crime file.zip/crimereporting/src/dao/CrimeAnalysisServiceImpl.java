packageutil;

import entity.*;
import util.DBConnUtil;
import com.hexaware.myexceptions.IncidentNumberNotFoundException;
import java.sql.*;
import java.sql.Date;
import java.util.*;


public class CrimeAnalysisServiceImpl implements ICrimeAnalysisService {

    private static Connection conn;

    public CrimeAnalysisServiceImpl() {
        conn = DBConnUtil.getConnection();
    }
    public boolean createIncident(Incident incident) {
        String sql = "INSERT INTO incidents (incident_type, incident_date, latitude, longitude, description, status, agency_id, officer_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, incident.getIncidentType());
            stmt.setDate(2, new java.sql.Date(incident.getIncidentDate().getTime()));
            stmt.setDouble(3, incident.getLatitude());
            stmt.setDouble(4, incident.getLongitude());
            stmt.setString(5, incident.getDescription());
            stmt.setString(6, incident.getStatus());
            stmt.setInt(7, incident.getAgencyId());
            stmt.setInt(8, incident.getOfficerId());

            int rows = stmt.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateIncidentStatus(int incidentId, String status) {
        String sql = "UPDATE incidents SET status = ? WHERE incident_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, incidentId);

            int rows = stmt.executeUpdate();
            if (rows == 0) {
                throw new Exception("Incident ID not found: " + incidentId);
            }

            return true;

        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
    }
    public List<Incident> getIncidentsInDateRange(Date startDate, Date endDate) {
        List<Incident> list = new ArrayList<>();
        String sql = "SELECT * FROM incidents WHERE incident_date BETWEEN ? AND ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, new java.sql.Date(startDate.getTime()));
            stmt.setDate(2, new java.sql.Date(endDate.getTime()));
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Incident inc = new Incident(
                    rs.getInt("incident_id"),
                    rs.getString("incident_type"),
                    rs.getDate("incident_date"),
                    rs.getDouble("latitude"),
                    rs.getDouble("longitude"),
                    rs.getString("description"),
                    rs.getString("status"),
                    rs.getInt("agency_id"),
                    rs.getInt("officer_id")
                );
                list.add(inc);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public List<Incident> searchIncidents(String incidentType) {
        List<Incident> list = new ArrayList<>();
        String sql = "SELECT * FROM incidents WHERE incident_type = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, incidentType);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Incident inc = new Incident(
                    rs.getInt("incident_id"),
                    rs.getString("incident_type"),
                    rs.getDate("incident_date"),
                    rs.getDouble("latitude"),
                    rs.getDouble("longitude"),
                    rs.getString("description"),
                    rs.getString("status"),
                    rs.getInt("agency_id"),
                    rs.getInt("officer_id")
                );
                list.add(inc);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

 
    public Report generateIncidentReport(Incident incident) {
        Report report = new Report();
        report.setIncidentId(incident.getIncidentId());
        report.setReportingOfficer(incident.getOfficerId());
        report.setReportDate(new java.util.Date());
        report.setReportDetails("Incident Report for: " + incident.getIncidentType());
        report.setStatus("draft");

      

        return report;
    }
	@Override
	public List<Incident> getIncidentsInDateRange(java.util.Date startDate, java.util.Date endDate) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean updateIncidentStatus(String newStatus, int id) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public List<Incident> getIncidentsInDateRange(String start, String end) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Report generateIncidentReport(int id) {
		// TODO Auto-generated method stub
		return null;
	}
}
