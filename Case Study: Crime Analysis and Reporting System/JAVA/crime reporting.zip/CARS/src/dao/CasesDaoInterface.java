package dao;

import entity.Cases;

public interface CasesDaoInterface{
	  public void putCaseToArray();
	  public void addCase(Cases cases);
}
