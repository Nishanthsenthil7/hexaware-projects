package controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import dao.SuspectsDao;
import entity.Suspects;
import exception.DuplicateDataException;
import exception.InvalidDataException;

public class SuspectController {
  public static List<Suspects> suspectsList = new ArrayList<>();
  private SuspectsDao suspectDataAccessObject = new SuspectsDao();
  private InputStreamReader inputStreamReader = new InputStreamReader(System.in);
  private BufferedReader bufferReader = new BufferedReader(inputStreamReader);
  private Suspects suspect;
  public void putSuspectsToArray() {
    suspectsList.clear(); 
    suspectDataAccessObject.putSuspectsToArray();
    suspectsList.addAll(SuspectController.suspectsList);
  }
  public void showSuspects() {
    for (Suspects s : suspectsList) {
      System.out.println(s);
    }
  }
  public void addSuspect() {
    StringBuffer str = new StringBuffer("");
    suspect=new Suspects();
    try {
    	System.out.println("Enter Suspect Id:");
    	str=str.append(bufferReader.readLine());
    	if(str.toString().equals("")||Integer.parseInt(str.toString())<0)
    		throw new InvalidDataException();
    	
    	suspect.setSuspectId(Integer.parseInt(str.toString()));
    	
    	System.out.println("Enter Suspects First Name:");
    	str.setLength(0);
    	str=str.append(bufferReader.readLine());
    	if(str.toString().equals(""))
    		throw new InvalidDataException();
    	suspect.setFirstName(str.toString());
    	
    	System.out.println("Enter Suspects Last Name:");
    	str.setLength(0);
    	str=str.append(bufferReader.readLine());
    	if(str.toString().equals(""))
    		throw new InvalidDataException();
    	suspect.setLastName(str.toString());	
    	
    	System.out.println("Enter Suspects DOB(yyyy-mm-dd):");
		str.setLength(0);
    	str=str.append(bufferReader.readLine());
    	 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    	LocalDate dob=LocalDate.parse(str.toString(),formatter);
    	if(dob.isAfter(LocalDate.now())||dob==null)
    		throw new InvalidDataException();
    	suspect.setDob(LocalDate.parse(str.toString()));
    	
    	System.out.println("Enter Suspects Gender:");
    	str.setLength(0);
    	str=str.append(bufferReader.readLine());
    	if(str.toString().equals(""))
    		throw new InvalidDataException();
    	suspect.setGender(str.toString());
    	
    	System.out.println("Enter Suspects ContactInfo:");
    	str.setLength(0);
    	str=str.append(bufferReader.readLine());
    	if(str.toString().equals(""))
    		throw new InvalidDataException();
    	suspect.setContactInfo(str.toString());
    	
    	boolean containsObject = suspectsList.stream()
                .anyMatch(obj -> obj.getSuspectId()==suspect.getSuspectId());
		
		
		if(containsObject) {
			throw new DuplicateDataException();
		}
    	
    	suspectsList.add(suspect);
    	suspectDataAccessObject.addSuspects(suspect);
    	
    }catch(IOException e) {
    	e.printStackTrace();
    } catch (InvalidDataException e) {
		System.err.println(e);
	} catch (DuplicateDataException e) {
		System.err.println(e);
	}
  }
}
