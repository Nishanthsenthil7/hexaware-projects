package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import java.io.FileInputStream;


public class DBConnUtil {
    public static Connection getConnection(String filePath) {
        Connection conn = null;
        try {
            Properties props = new Properties();
            FileInputStream fis = new FileInputStream(filePath);
            props.load(fis);

            String driver = props.getProperty("db.driver");
            String url = props.getProperty("db.url");
            String username = props.getProperty("db.username");
            String password = props.getProperty("db.password");

            Class.forName(driver);
            conn = DriverManager.getConnection(url, username, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
}