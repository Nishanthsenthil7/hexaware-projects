package main;

import dao.CrimeAnalysisServiceImpl;
import dao.ICrimeAnalysisService;
import entity.Incident;
import entity.Report;
import exception.IncidentNumberNotFoundException;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class MainModule {

    public static void main(String[] args) throws IncidentNumberNotFoundException {
        Scanner sc = new Scanner(System.in);
        ICrimeAnalysisService service = new CrimeAnalysisServiceImpl();
        int choice;

        do {
            System.out.println("\n=== Crime Analysis and Reporting System ===");
            System.out.println("1. Create Incident");
            System.out.println("2. Update Incident Status");
            System.out.println("3. View Incidents in Date Range");
            System.out.println("4. Search Incidents by Type");
            System.out.println("5. Generate Incident Report");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    try {
                        System.out.println("Enter Incident Type:");
                        String type = sc.nextLine();

                        System.out.println("Enter Incident Date (YYYY-MM-DD):");
                        LocalDate date = LocalDate.parse(sc.nextLine());

                        System.out.println("Enter Latitude:");
                        double lat = sc.nextDouble();
                        System.out.println("Enter Longitude:");
                        double lon = sc.nextDouble();
                        sc.nextLine(); // consume newline

                        System.out.println("Enter Description:");
                        String desc = sc.nextLine();

                        System.out.println("Enter Status:");
                        String status = sc.nextLine();

                        System.out.println("Enter Agency ID:");
                        int agencyId = sc.nextInt();
                        System.out.println("Enter Officer ID:");
                        int officerId = sc.nextInt();

                        Incident incident = new Incident(0, type, date, lat, lon, desc, status, agencyId, officerId);

                        boolean created = service.createIncident(incident);
                        System.out.println(created ? "Incident created successfully!" : "Failed to create incident.");
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 2:
                    try {
                        System.out.print("Enter Incident ID: ");
                        int id = sc.nextInt();
                        sc.nextLine(); 

                        System.out.print("Enter new status: ");
                        String newStatus = sc.nextLine();

                        boolean updated = service.updateIncidentStatus(newStatus, id);
                        System.out.println(updated ? "Incident updated!" : "Update failed.");
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 3:
                    try {
                        System.out.print("Enter Start Date (YYYY-MM-DD): ");
                        String start = sc.nextLine();

                        System.out.print("Enter End Date (YYYY-MM-DD): ");
                        String end = sc.nextLine();

                        List<Incident> rangeList = service.getIncidentsInDateRange(start, end);
                        if (rangeList.isEmpty()) {
                            System.out.println("No incidents found in the given date range.");
                        } else {
                            rangeList.forEach(System.out::println);
                        }
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 4:
                    try {
                        System.out.print("Enter Incident Type: ");
                        String type = sc.nextLine();

                        List<Incident> searchResults = service.searchIncidents(type);
                        if (searchResults.isEmpty()) {
                            System.out.println("No incidents found for the given type.");
                        } else {
                            searchResults.forEach(System.out::println);
                        }
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 5:
                    try {
                        System.out.print("Enter Incident ID: ");
                        int id = sc.nextInt();
                        sc.nextLine();

                        Report report = service.generateIncidentReport(id);
                        if (report != null) {
                            System.out.println("=== Report Details ===");
                            System.out.println(report);
                        } else {
                            System.out.println("No report found for this incident.");
                        }
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 6:
                    System.out.println("Exiting... Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 6);

        sc.close();
    }
}
