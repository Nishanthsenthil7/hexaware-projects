package main;

import java.util.*;
import entity.Product;
import entity.User;
import exception.OrderNotFoundException;
import exception.UserNotFoundException;

public class MainModule {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        OrderProcessor processor = new OrderProcessor();

        while (true) {
            System.out.println("\n===== WELCOME TO HEXAMART =====");
            System.out.println("1. Create User");
            System.out.println("2. Create Product");
            System.out.println("3. Create Order");
            System.out.println("4. Cancel Order");
            System.out.println("5. Get All Products");
            System.out.println("6. Get Orders by User");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter User ID: ");
                    int user_id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Username: ");
                    String username = sc.nextLine();
                    System.out.print("Enter Password: ");
                    String password = sc.nextLine();
                    System.out.print("Enter Role (Admin/User): ");
                    String role = sc.nextLine();

                    User newUser = new User(user_id, username, password, role);
                    processor.createUser(newUser);
                    break;

                case 2:
                    System.out.print("Enter Admin User ID: ");
                    int adminId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Username: ");
                    String adminName = sc.nextLine();
                    System.out.print("Enter Password: ");
                    String adminPass = sc.nextLine();
                    User adminUser = new User(adminId, adminName, adminPass, "Admin");

                    System.out.print("Enter Product ID: ");
                    int pid = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Product Name: ");
                    String pname = sc.nextLine();
                    System.out.print("Enter Description: ");
                    String desc = sc.nextLine();
                    System.out.print("Enter Price: ");
                    double price = sc.nextDouble();
                    System.out.print("Enter Quantity: ");
                    int qty = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Type (Electronics/Clothing): ");
                    String type = sc.nextLine();

                    Product product = new Product(pid, pname, desc, price, qty, type);
                    try {
                        processor.createProduct(adminUser, product);
                    } catch (UserNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 3:
                    System.out.print("Enter User ID: ");
                    int ouserId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Username: ");
                    String ouserName = sc.nextLine();
                    System.out.print("Enter Password: ");
                    String ouserPass = sc.nextLine();
                    User orderUser = new User(ouserId, ouserName, ouserPass, "User");

                    System.out.print("How many products to order? ");
                    int count = sc.nextInt();
                    List<Product> orderList = new ArrayList<>();
                    for (int i = 0; i < count; i++) {
                        System.out.print("Enter Product ID " + (i + 1) + ": ");
                        int opid = sc.nextInt();
                        orderList.add(new Product(opid)); 
                    }

                    try {
                        processor.createOrder(orderUser, orderList);
                    } catch (UserNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 4:
                    System.out.print("Enter User ID: ");
                    int cuserId = sc.nextInt();
                    System.out.print("Enter Order ID: ");
                    int orderId = sc.nextInt();
                    try {
                        processor.cancelOrder(cuserId, orderId);
                    } catch (UserNotFoundException | OrderNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 5:
                    List<Product> allProducts = processor.getAllProducts();
                    for (Product p : allProducts) {
                        System.out.println(p);
                    }
                    break;

                case 6:
                    System.out.print("Enter User ID: ");
                    int guserId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Username: ");
                    String gusername = sc.nextLine();
                    System.out.print("Enter Password: ");
                    String gpassword = sc.nextLine();
                    User guser = new User(guserId, gusername, gpassword, "User");

                    try {
                        List<Product> userOrders = processor.getOrderByUser(guser);
                        for (Product p : userOrders) {
                            System.out.println(p);
                        }
                    } catch (UserNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 7:
                    System.out.println("Exiting the system. THANKYOU VISIT AGAIN");
                    sc.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
    
}