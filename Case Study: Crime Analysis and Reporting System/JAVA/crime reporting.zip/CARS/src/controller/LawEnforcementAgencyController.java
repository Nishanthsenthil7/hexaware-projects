package controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import dao.AgencyDao;
import entity.LawEnforcementAgencies;
import exception.DuplicateDataException;
import exception.InvalidDataException;


public class LawEnforcementAgencyController {
    public static List<LawEnforcementAgencies> agencyList = new ArrayList<>();
    private AgencyDao agencyDao = new AgencyDao();
    private InputStreamReader inputStreamReader = new InputStreamReader(System.in);
    private BufferedReader bufferReader = new BufferedReader(inputStreamReader);
    private LawEnforcementAgencies agency;
	public void putAgenciesToArray() {
		agencyDao.putSuspectsToArray();
	}
	public void addAgency() {
		StringBuffer str=new StringBuffer("");
		agency=new LawEnforcementAgencies();
		try {
			System.out.println("Enter Agency Id:");
			str=str.append(bufferReader.readLine());
			if(str.toString().equals("")||Integer.parseInt(str.toString())<0)
				throw new InvalidDataException();
			agency.setAgencyId(Integer.parseInt(str.toString()));

			System.out.println("Enter Agency Name:");
			str.setLength(0);
			str=str.append(bufferReader.readLine());
			if(str.toString().equals(""))
				throw new InvalidDataException();
			agency.setAgencyName(str.toString());
			
			System.out.println("Enter Agency Jurisdiction:");
			str.setLength(0);
			str=str.append(bufferReader.readLine());
			if(str.toString().equals(""))
				throw new InvalidDataException();
			agency.setJurisdiction(str.toString());
			
			System.out.println("Enter Agencies contact Info:");
			str.setLength(0);
			str=str.append(bufferReader.readLine());
			if(str.toString().equals(""))
				throw new InvalidDataException();
			agency.setContactInfo(str.toString());
			
			boolean containsObject = agencyList.stream()
	                .anyMatch(obj -> obj.getAgencyId()==agency.getAgencyId());
			
			
			if(containsObject) {
				throw new DuplicateDataException();
			}
			
			agencyList.add(agency);
			agencyDao.addAgency(agency);			
		}catch(IOException e) {
			e.printStackTrace();
		} catch (InvalidDataException e) {
			System.err.println(e);
		} catch (DuplicateDataException e) {
			System.err.println(e);
		}
	}
	public void showAllAgencies() {
		for(LawEnforcementAgencies l:agencyList) {
			System.out.println(l);
		}
	}
}