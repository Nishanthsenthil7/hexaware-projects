package com.cars.util;

public @interface Test {

}
