package entity;

public class LawEnforcementAgency {
    private int agencyId;
    private String agencyName;
    private String jurisdiction;
    private String contactInformation;

    public LawEnforcementAgency() {}

    public LawEnforcementAgency(int agencyId, String agencyName, String jurisdiction, String contactInformation) {
        this.setAgencyId(agencyId);
        this.setAgencyName(agencyName);
        this.setJurisdiction(jurisdiction);
        this.setContactInformation(contactInformation);
    }

	public int getAgencyId() {
		return agencyId;
	}

	public void setAgencyId(int agencyId) {
		this.agencyId = agencyId;
	}

	public String getAgencyName() {
		return agencyName;
	}

	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	public String getJurisdiction() {
		return jurisdiction;
	}

	public void setJurisdiction(String jurisdiction) {
		this.jurisdiction = jurisdiction;
	}

	public String getContactInformation() {
		return contactInformation;
	}

	public void setContactInformation(String contactInformation) {
		this.contactInformation = contactInformation;
	}

}
