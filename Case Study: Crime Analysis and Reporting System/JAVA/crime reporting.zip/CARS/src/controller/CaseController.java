package controller;

import java.io.BufferedReader; 
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import dao.CasesDao;
import entity.Cases;
import entity.Incidents;
import exception.DuplicateDataException;
import exception.IncidentNumberNotFoundException;
import exception.InvalidDataException;

public class CaseController {
    public static List<Cases> caseList = new ArrayList<>();
    private InputStreamReader inputStreamReader = new InputStreamReader(System.in);
    private BufferedReader bufferReader = new BufferedReader(inputStreamReader);
    private CasesDao caseDao = new CasesDao();
    private Cases cases;
    public void putCasesToArray() {
        caseDao.putCaseToArray();
    }
	public void addCase() {
		StringBuffer str=new StringBuffer("");
		cases=new Cases();
		try {
			System.out.println("Enter Case Id:");
			str=str.append(bufferReader.readLine());
			if(str.toString().equals("")||str.toString().contains("-"))
				throw new InvalidDataException();
			cases.setCaseId(Integer.parseInt(str.toString()));
			
			System.out.println("Enter Related Incident Id:");
			str.setLength(0);
			str=str.append(bufferReader.readLine());
			if(str.toString().equals("")||str.toString().contains("-"))
				throw new InvalidDataException();
			
			boolean isIncidentAvailable=false;
			for(Incidents i:IncidentController.incidentList) {
				if(i.getIncidentId()==Integer.parseInt(str.toString())) {
					isIncidentAvailable=true;
					cases.setRelatedIncidents(i);
					break;
				}
			}
			if(!isIncidentAvailable)
				throw new IncidentNumberNotFoundException();
			
			System.out.println("Enter Case Description:");
			str.setLength(0);
			str=str.append(bufferReader.readLine());
			if(str.toString().equals(""))
				throw new InvalidDataException();
			cases.setCaseDescription(str.toString());
			
			boolean containsObject = caseList.stream()
	                .anyMatch(obj -> obj.getCaseId()==cases.getCaseId());
			
			
			if(containsObject) {
				throw new DuplicateDataException();
			}
			
			caseList.add(cases);
			caseDao.addCase(cases);
			System.out.println("Case Added Succesfully!!");
		}catch(InvalidDataException e) {
			System.err.println(e);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (IncidentNumberNotFoundException e) {
			System.err.println(e);
		} catch (DuplicateDataException e) {
			System.err.println(e);
		}
	}
    public void getAllCases() {
        caseList = caseDao.getAllCases();
        for (Cases cases : caseList) {
            System.out.println(cases);
        }
    }
    public void updateCase(int id) {
		StringBuffer str=new StringBuffer("");
		cases=new Cases();
		char ch;
		Scanner sc=new Scanner(System.in);
		try {
			for(Cases cases:caseList){
				if(cases.getCaseId()==id) {
					System.out.println("Update Incident? (y/n)");
					ch=sc.next().charAt(0);
					if(ch=='y') {
						System.out.println("Enter Related Incident Id:");
						str=str.append(bufferReader.readLine());
						if(str.toString().equals("")||str.toString().contains("-"))
							throw new InvalidDataException();
						
						boolean isIncidentAvailable=false;
						for(Incidents i:IncidentController.incidentList) {
							if(i.getIncidentId()==Integer.parseInt(str.toString())) {
								isIncidentAvailable=true;
								cases.setRelatedIncidents(i);
								break;
							}
						}
						if(!isIncidentAvailable)
							throw new IncidentNumberNotFoundException();
						
					}
					
					System.out.println("Update Case Description? (y/n)");
					ch=sc.next().charAt(0);
					if(ch=='y') {
						System.out.println("Enter Case Description:");
						str.setLength(0);
						str=str.append(bufferReader.readLine());
						if(str.toString().equals(""))
							throw new InvalidDataException();
						cases.setCaseDescription(str.toString());
					}
					caseDao.updateCaseDetails(cases);
				}
			}
		}catch(Exception e) {
			System.err.println(e);
		}
	}
	public void getCase(int id) {
		for(Cases c:caseList) {
			if(c.getCaseId()==id) {
				System.out.println(c);
				return;
			}
		}
	}
}
