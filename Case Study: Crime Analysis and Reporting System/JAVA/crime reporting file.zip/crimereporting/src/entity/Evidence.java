package entity;

public class Evidence {
    private int evidenceId;
    private String description;
    private String locationFound;
    private int incidentId;

    public Evidence() {}

    public Evidence(int evidenceId, String description, String locationFound, int incidentId) {
        this.setEvidenceId(evidenceId);
        this.setDescription(description);
        this.setLocationFound(locationFound);
        this.setIncidentId(incidentId);
    }

	public int getEvidenceId() {
		return evidenceId;
	}

	public void setEvidenceId(int evidenceId) {
		this.evidenceId = evidenceId;
	}

	public String getLocationFound() {
		return locationFound;
	}

	public void setLocationFound(String locationFound) {
		this.locationFound = locationFound;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getIncidentId() {
		return incidentId;
	}

	public void setIncidentId(int incidentId) {
		this.incidentId = incidentId;
	}

   
}
