package dao;

import java.time.LocalDate;
import java.util.List;
import entity.Incidents;

public interface IncidentDaoInterface {
	  public void CreateIncident(Incidents object);
	  public boolean insertIncident(int id, String type, LocalDate date, String location, String description,
	                                String status, int victimId, int suspectId, int agencyId);
	  public void displayIncident(int id);
	  public List<Incidents> getIncidentsInDateRange(
	      LocalDate startDate, 
	      LocalDate endDate);
	  public void updateIncident(Incidents incident);
	  public boolean updateIncidentStatus(int id, String status);
}
