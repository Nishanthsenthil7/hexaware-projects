package com.cars.util;

public @interface BeforeEach {

}
