package controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import dao.ReportsDao;
import entity.Incidents;
import entity.Officers;
import entity.Reports;
import exception.DuplicateDataException;
import exception.InvalidDataException;
import exception.RecordNotFoundException;

public class ReportController {
    public static List<Reports> reportsList = new ArrayList<>();
    private InputStreamReader inputStreamReader = new InputStreamReader(System.in);
    private BufferedReader bufferReader = new BufferedReader(inputStreamReader);
    private Reports report;
    private ReportsDao reportsDataAccessObject = new ReportsDao();
	public void putReportsToArray() {
		reportsDataAccessObject.putReportsToArray();
	}
	public void addReport() {
		StringBuffer str=new StringBuffer("");
		report=new Reports();
		boolean isAvailable=false;
		try {
			System.out.print("Enter Report Id: ");
			str=str.append(bufferReader.readLine());
			if(str.toString().equals("")||Integer.parseInt(str.toString())<0)
				throw new InvalidDataException();
			report.setReportId(Integer.parseInt(str.toString()));
			
			System.out.print("Enter Incident id: ");
			str.setLength(0);
			str=str.append(bufferReader.readLine());
			if(str.toString().equals("")||Integer.parseInt(str.toString())<0)
				throw new InvalidDataException();
			
			for(Incidents i:IncidentController.incidentList) {
				if(i.getIncidentId()==Integer.parseInt(str.toString())) {
					report.setIncident(i);
					isAvailable=true;
					break;
				}
			}
			if(isAvailable==false)
				throw new RecordNotFoundException();
			isAvailable=false;
			
			System.out.print("Enter Reporting Officer Id: ");
			str.setLength(0);
			str=str.append(bufferReader.readLine());
			if(str.toString().equals("")||Integer.parseInt(str.toString())<0)
				throw new InvalidDataException();
			
			for(Officers s:OfficerController.officerList) {
				if(s.getOfficerId()==Integer.parseInt(str.toString())) {
					report.setReportingOfficer(s);
					isAvailable=true;
					break;
				}
			}
			if(isAvailable==false)throw new RecordNotFoundException();
			isAvailable=false;
			
			System.out.print("Enter Report Date: ");
			str.setLength(0);
			str=str.append(bufferReader.readLine());
			if(str.toString().equals("")) 
				throw new InvalidDataException();
			
			report.setReportDate(LocalDate.parse(str.toString()));
			
			System.out.print("Enter Report Details: ");
			str.setLength(0);
			str=str.append(bufferReader.readLine());
			if(str.toString().equals("")) 
				throw new InvalidDataException();
			report.setReportDetails(str.toString());

			System.out.println("Enter Report Status: ");
			str.setLength(0);
			str=str.append(bufferReader.readLine());
			if(str.toString().equals("")) 
				throw new InvalidDataException();
			report.setReportStatus(str.toString());
			
		    boolean containsObject = reportsList.stream()
	                .anyMatch(obj -> obj.getReportId()==report.getReportId());
			
			
			if(containsObject) {
				throw new DuplicateDataException();
			}
			reportsList.add(report);
			if(reportsDataAccessObject.addReport(report)) {
				System.out.println("Data inserted Successfully!!");
			}else {
				System.err.println("Data could not be inserted!!");
			}
			
		}catch(IOException e) {
			e.printStackTrace();
		} catch (InvalidDataException e) {
			System.err.println(e);
		}catch(DuplicateDataException e) {
			System.err.println(e);
		} catch (RecordNotFoundException e) {
			// TODO Auto-generated catch block
			System.err.println(e);
		}
	}
	public void displayReports() {
		for(Reports r:reportsList) {
			System.out.println(r);
		}
	}
	public void getReportById(int id) throws RecordNotFoundException {
		boolean isAvailable=false;
		for(Reports r:reportsList) {
			if(r.getReportId()==id) {
				System.out.println(r);
				return;
			}
		}
		if(isAvailable==false)
			throw new RecordNotFoundException();
	}
	
}
