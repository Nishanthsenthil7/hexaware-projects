package entity;

public class Officer {
    private int officerId;
    private String firstName;
    private String lastName;
    private String badgeNumber;
    private String rank;
    private String contactInformation;
    private int agencyId;

    public Officer() {}

    public Officer(int officerId, String firstName, String lastName, String badgeNumber, String rank, String contactInformation, int agencyId) {
        this.setOfficerId(officerId);
        this.setFirstName(firstName);
        this.setLastName(lastName);
        this.setBadgeNumber(badgeNumber);
        this.setRank(rank);
        this.setContactInformation(contactInformation);
        this.setAgencyId(agencyId);
    }

	public int getOfficerId() {
		return officerId;
	}

	public void setOfficerId(int officerId) {
		this.officerId = officerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBadgeNumber() {
		return badgeNumber;
	}

	public void setBadgeNumber(String badgeNumber) {
		this.badgeNumber = badgeNumber;
	}

	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}

	public String getContactInformation() {
		return contactInformation;
	}

	public void setContactInformation(String contactInformation) {
		this.contactInformation = contactInformation;
	}

	public int getAgencyId() {
		return agencyId;
	}

	public void setAgencyId(int agencyId) {
		this.agencyId = agencyId;
	}

  
}
