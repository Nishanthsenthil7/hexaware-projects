package main;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import dao.IOrderManagementRepository;
import entity.Product;
import entity.User;
import exception.OrderNotFoundException;
import exception.UserNotFoundException;
import util.DBConnUtil;

public class OrderProcessor implements IOrderManagementRepository {

    private final String propFilePath = "src/db.properties";

    @Override
    public void createUser(User user) {
        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO users (user_id, username, password, role) VALUES (?, ?, ?, ?)");
            ps.setInt(1, user.getUserId());
            ps.setString(2, user.getUsername());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getRole());
            ps.executeUpdate();
            System.out.println("User created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void createProduct(User user, Product product) throws UserNotFoundException {
        if (!isAdmin(user)) throw new UserNotFoundException("Only admin can create products!");

        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO products (productId, productName, description, price, quantityInStock, type) VALUES (?, ?, ?, ?, ?, ?)");
            ps.setInt(1, product.getProductId());
            ps.setString(2, product.getProductName());
            ps.setString(3, product.getDescription());
            ps.setDouble(4, product.getPrice());
            ps.setInt(5, product.getQuantityInStock());
            ps.setString(6, product.getType());
            ps.executeUpdate();
            System.out.println("✅ Product created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void createOrder(User user, List<Product> products) throws UserNotFoundException {
        if (!userExists(user)) throw new UserNotFoundException("User not found!");

        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
            conn.setAutoCommit(false);

            PreparedStatement psOrder = conn.prepareStatement("INSERT INTO orders (user_id) VALUES (?)", Statement.RETURN_GENERATED_KEYS);
            psOrder.setInt(1, user.getUserId());
            psOrder.executeUpdate();

            ResultSet rs = psOrder.getGeneratedKeys();
            int orderId = -1;
            if (rs.next()) orderId = rs.getInt(1);

            PreparedStatement psDetails = conn.prepareStatement("INSERT INTO order_details (order_id, product_id) VALUES (?, ?)");
            for (Product p : products) {
                psDetails.setInt(1, orderId);
                psDetails.setInt(2, p.getProductId());
                psDetails.addBatch();
            }

            psDetails.executeBatch();
            conn.commit();
            System.out.println("✅ Order created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException {
        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
            PreparedStatement checkUser = conn.prepareStatement("SELECT * FROM users WHERE userId = ?");
            checkUser.setInt(1, userId);
            ResultSet userRs = checkUser.executeQuery();
            if (!userRs.next()) throw new UserNotFoundException("User ID not found!");

            PreparedStatement checkOrder = conn.prepareStatement("SELECT * FROM orders WHERE order_id = ?");
            checkOrder.setInt(1, orderId);
            ResultSet orderRs = checkOrder.executeQuery();
            if (!orderRs.next()) throw new OrderNotFoundException("Order ID not found!");

            PreparedStatement deleteOrderDetails = conn.prepareStatement("DELETE FROM order_details WHERE order_id = ?");
            deleteOrderDetails.setInt(1, orderId);
            deleteOrderDetails.executeUpdate();

            PreparedStatement deleteOrder = conn.prepareStatement("DELETE FROM orders WHERE order_id = ?");
            deleteOrder.setInt(1, orderId);
            deleteOrder.executeUpdate();

            System.out.println("✅ Order canceled successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> list = new ArrayList<>();
        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM products");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Product p = new Product(
                        rs.getInt("productId"),
                        rs.getString("productName"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("quantityInStock"),
                        rs.getString("type")
                );
                list.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Product> getOrderByUser(User user) throws UserNotFoundException {
        if (!userExists(user)) throw new UserNotFoundException("User not found!");

        List<Product> list = new ArrayList<>();
        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
            String query = "SELECT p.* FROM products p " +
                           "JOIN order_details od ON p.productId = od.product_id " +
                           "JOIN orders o ON od.order_id = o.order_id " +
                           "WHERE o.user_id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, user.getUserId());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Product p = new Product(
                        rs.getInt("productId"),
                        rs.getString("productName"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("quantityInStock"),
                        rs.getString("type")
                );
                list.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }


    private boolean userExists(User user) {
        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE userId = ?");
            ps.setInt(1, user.getUserId());
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            return false;
        }
    }

    private boolean isAdmin(User user) {
        return "Admin".equalsIgnoreCase(user.getRole()) && userExists(user);
    }
}