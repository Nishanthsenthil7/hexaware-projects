package com.cars.util;

public class IncidentDAO {

	public boolean createIncident(Incident incident) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean updateIncidentStatus(int i, String string) {
		// TODO Auto-generated method stub
		return false;
	}

	public Incident getIncidentById(int i) {
		// TODO Auto-generated method stub
		return null;
	}

}
