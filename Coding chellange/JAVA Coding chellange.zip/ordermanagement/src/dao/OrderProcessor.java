package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import entity.Product;
import entity.User;
import exception.OrderNotFoundException;
import exception.UserNotFoundException;
import util.DBConnUtil;


	class OrderProcessor implements IOrderManagementRepository {

	    private final String propFilePath = "src/db.properties";
	    
	    

	    @Override
	    public void createUser(User user) {
	        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
	            PreparedStatement ps = conn.prepareStatement("INSERT INTO users (user_id, username, password, role) VALUES (?, ?, ?, ?)");
	            ps.setInt(1, user.getUserId());
	            ps.setString(2, user.getUsername());
	            ps.setString(3, user.getPassword());
	            ps.setString(4, user.getRole());
	            ps.executeUpdate();
	            System.out.println("User created successfully.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	    public void createProduct(User user, Product product) throws UserNotFoundException {
	        if (!isAdmin(user)) throw new UserNotFoundException("Only admin can add products!");

	        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
	            PreparedStatement ps = conn.prepareStatement("INSERT INTO products (productId, productName, description, price, quantityInStock, type) VALUES (?, ?, ?, ?, ?, ?)");
	            ps.setInt(1, product.getProductId());
	            ps.setString(2, product.getProductName());
	            ps.setString(3, product.getDescription());
	            ps.setDouble(4, product.getPrice());
	            ps.setInt(5, product.getQuantityInStock());
	            ps.setString(6, product.getType());
	            ps.executeUpdate();
	            System.out.println("Product added successfully.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	    public void createOrder(User user, List<Product> products) throws UserNotFoundException {
	        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
	            conn.setAutoCommit(false);

	            PreparedStatement orderStmt = conn.prepareStatement("INSERT INTO orders (user_id) VALUES (?)", Statement.RETURN_GENERATED_KEYS);
	            orderStmt.setInt(1, user.getUserId());
	            orderStmt.executeUpdate();

	            ResultSet rs = orderStmt.getGeneratedKeys();
	            int orderId = -1;
	            if (rs.next()) orderId = rs.getInt(1);

	            PreparedStatement detailStmt = conn.prepareStatement("INSERT INTO order_details (order_id, product_id) VALUES (?, ?)");
	            for (Product p : products) {
	                detailStmt.setInt(1, orderId);
	                detailStmt.setInt(2, p.getProductId());
	                detailStmt.addBatch();
	            }
	            detailStmt.executeBatch();
	            conn.commit();
	            System.out.println("Order placed successfully.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	    public void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException {
	        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
	            PreparedStatement ps = conn.prepareStatement("DELETE FROM orders WHERE order_id = ? AND user_id = ?");
	            ps.setInt(1, orderId);
	            ps.setInt(2, userId);
	            int rows = ps.executeUpdate();
	            if (rows == 0) throw new OrderNotFoundException("Order or User not found!");
	            System.out.println("Order canceled successfully.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	    public List<Product> getAllProducts() {
	        List<Product> list = new ArrayList<>();
	        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
	            PreparedStatement ps = conn.prepareStatement("SELECT * FROM products");
	            ResultSet rs = ps.executeQuery();
	            while (rs.next()) {
	                Product p = new Product(
	                        rs.getInt("productId"),
	                        rs.getString("productName"),
	                        rs.getString("description"),
	                        rs.getDouble("price"),
	                        rs.getInt("quantityInStock"),
	                        rs.getString("type")
	                );
	                list.add(p);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return list;
	    }

	    @Override
	    public List<Product> getOrderByUser(User user) throws UserNotFoundException {
	        List<Product> list = new ArrayList<>();
	        try (Connection conn = DBConnUtil.getConnection(propFilePath)) {
	            String sql = "SELECT p.* FROM products p " +
	                         "JOIN order_details od ON p.productId = od.product_id " +
	                         "JOIN orders o ON o.order_id = od.order_id " +
	                         "WHERE o.user_id = ?";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ps.setInt(1, user.getUserId());
	            ResultSet rs = ps.executeQuery();
	            while (rs.next()) {
	                Product p = new Product(
	                        rs.getInt("productId"),
	                        rs.getString("productName"),
	                        rs.getString("description"),
	                        rs.getDouble("price"),
	                        rs.getInt("quantityInStock"),
	                        rs.getString("type")
	                );
	                list.add(p);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return list;
	    }

	    private boolean isAdmin(User user) {
	        return user != null && "Admin".equalsIgnoreCase(user.getRole());
	    }
	}
	
	

