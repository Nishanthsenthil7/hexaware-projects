package controller;

public enum Status {
    OPEN, CLOSED, UNDER_INVESTIGATION
}
