package dao;

import entity.*;
import java.util.*;

public interface ICrimeAnalysisService {
    
    boolean createIncident(Incident incident);

    boolean updateIncidentStatus(int incidentId, String status);

    List<Incident> getIncidentsInDateRange(Date startDate, Date endDate);

    List<Incident> searchIncidents(String incidentType);

    Report generateIncidentReport(Incident incident);

	boolean updateIncidentStatus(String newStatus, int id);

	List<Incident> getIncidentsInDateRange(String start, String end);

	Report generateIncidentReport(int id);
}
