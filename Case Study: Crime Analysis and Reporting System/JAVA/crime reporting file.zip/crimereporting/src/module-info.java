module crimereporting {
	requires java.sql;
}