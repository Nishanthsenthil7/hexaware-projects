package com.cars.util;

import java.time.LocalDate;

public class Incident {

	public Incident(int i, String string, String string2, LocalDate of, int j, int k) {
		// TODO Auto-generated constructor stub
	}

	public Object getStatus() {
		// TODO Auto-generated method stub
		return null;
	}

}
