package com.cars.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;
public class Junitz {
    private IncidentDAO incidentDAO;
    @BeforeEach
    void setUp() {
        incidentDAO = new IncidentDAO(); 
    }

    @Test
    void testCreateIncident() {
        Incident incident = new Incident(
                1,                    
                "Robbery",            
                "Open",                
                LocalDate.of(2024, 4, 8),
                101,                   
                201                   
        );
        boolean result = incidentDAO.createIncident(incident);
        assertTrue(result, "Incident should be created successfully.");
    }
    private void assertTrue(boolean result, String string) {	
	}
	@Test
    void testUpdateIncidentStatus() {
        Incident incident = new Incident(
                2,
                "Theft",
                "Open",
                LocalDate.of(2024, 4, 8),
                102,
                202
        );
        incidentDAO.createIncident(incident);
        boolean isUpdated = incidentDAO.updateIncidentStatus(2, "Closed");
        assertTrue(isUpdated, "Incident status should be updated to Closed.");
        Incident updated = incidentDAO.getIncidentById(2);
        assertEquals("Closed", updated.getStatus(), "Status should now be 'Closed'.");
    }
	private void assertEquals(String string, Object status, String string2) {	
	}
}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

