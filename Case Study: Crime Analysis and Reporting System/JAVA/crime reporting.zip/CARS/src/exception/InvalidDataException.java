package exception;

public class InvalidDataException extends Exception {

}
