package com.cars.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class IncidentDAOTest {

    private IncidentDAO incidentDAO;

    @BeforeEach
    void setUp() {
        incidentDAO = new IncidentDAO();
    }

    @Test
    void testCreateIncident_ShouldReturnTrue_WhenValidIncidentProvided() {
        Incident incident = new Incident(
                1,
                "Robbery",
                "Open",
                LocalDate.of(2024, 4, 8),
                101, // officerId
                201  // victimId
        );

        boolean result = incidentDAO.createIncident(incident);
        assertTrue(result, "Incident should be created successfully.");
    }

    @Test
    void testUpdateIncidentStatus_ShouldChangeStatusToClosed_WhenValidStatusProvided() {
        // First create the incident
        Incident incident = new Incident(
                2,
                "Theft",
                "Open",
                LocalDate.of(2024, 4, 8),
                102,
                202
        );
        incidentDAO.createIncident(incident);

        // Update the status
        boolean updated = incidentDAO.updateIncidentStatus(2, "Closed");
        assertTrue(updated, "Status should be updated successfully.");

        // Optionally, verify the new status
        Incident updatedIncident = incidentDAO.getIncidentById(2);
        assertEquals("Closed", updatedIncident.getStatus(), "Status should be 'Closed'");
    }
}
